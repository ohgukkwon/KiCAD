# Skeleton for ATmega328p based microcontroller projects


**Description:** KiCad project files that can be used as the starting point for an ATmega328p based microcontroller pcb project

![schematic](https://i.imgur.com/cF0mmdU.png)

